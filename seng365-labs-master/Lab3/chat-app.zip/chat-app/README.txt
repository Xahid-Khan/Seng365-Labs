Reference API implementation for SENG365 Lab 2

Instructions:
1. Run "npm install"
2. Add your .env file (as done for lab 2)
3. Run "npm run start"
